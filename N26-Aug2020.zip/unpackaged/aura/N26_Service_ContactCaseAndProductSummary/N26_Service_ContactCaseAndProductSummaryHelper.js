({
	getRecordList : function(component, event, helper) {
        var action = component.get("c.getProductDetails");

        action.setParams({
            "CaseId": component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            if(response.getState()==="SUCCESS"){
                console.log('Here');
                console.log("RESPONSE: " + JSON.stringify(response.getReturnValue()));
                var result = [];
                if(response.getReturnValue().length > 0){
                	result = result.concat(response.getReturnValue());
                }
                component.set("v.productSummary", result);
                console.log("RESPONSE 2: " +component.get("v.productSummary"));
            }
            else{
                helper.showErrToast(component, event, helper);
            }
        });
        
        $A.enqueueAction(action);
	},
    
	showErrToast : function(component, event, helper) {
        var toastEvent = $A.get("e.force:showToast");
        
        toastEvent.setParams({
            "title": "Alert!",
            "type": "warning",
            "mode": "sticky",
            "message": "There's error in fetching your product details. Please contact Admin"
        });
        toastEvent.fire();
	}
})